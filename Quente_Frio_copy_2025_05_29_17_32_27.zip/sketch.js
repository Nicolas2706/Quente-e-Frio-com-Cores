let xAlvo;
let yAlvo;

function setup() {
  createCanvas(600, 400);
  xAlvo = random(0, width);
  yAlvo = random(0, height);
}

function draw() {
  background(220);

  // Calcula a distância entre o mouse e o alvo
  let distancia = dist(mouseX, mouseY, xAlvo, yAlvo);

  // Muda a cor conforme a distância
  if (distancia < 30) {
    fill(255, 0, 0); // Quente (vermelho)
  } else if (distancia < 100) {
    fill(255, 165, 0); // Morno (laranja)
  } else {
    fill(0, 0, 255); // Frio (azul)
  }

  noStroke();
  ellipse(mouseX, mouseY, 30, 30); // Círculo que segue o mouse
}

function mousePressed() {
  let distancia = dist(mouseX, mouseY, xAlvo, yAlvo);

  // Se estiver bem perto, considera que acertou
  if (distancia < 30) {
    alert("🎯 Você encontrou o ponto escondido!");
    xAlvo = random(0, width);
    yAlvo = random(0, height);
  }
}